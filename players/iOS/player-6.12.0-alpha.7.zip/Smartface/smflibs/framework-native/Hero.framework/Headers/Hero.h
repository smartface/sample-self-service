//
//  Hero.h
//  Hero
//
//  Created by YiLun Zhao on 2017-01-03.
//  Copyright © 2017 Luke Zhao. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Hero.
FOUNDATION_EXPORT double HeroVersionNumber;

//! Project version string for Hero.
FOUNDATION_EXPORT const unsigned char HeroVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Hero/PublicHeader.h>

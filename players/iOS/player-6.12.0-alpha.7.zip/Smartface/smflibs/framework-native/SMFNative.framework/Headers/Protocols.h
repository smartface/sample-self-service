//
//  Protocols.h
//  SMFNative
//
//  Created by Dogan Ekici on 23/03/2017.
//  Copyright © 2017 Dogan Ekici. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <JavaScriptCore/JavaScriptCore.h>

@interface Protocols : NSObject

+(void)setContext:(JSContext*)context;
    
@end

//
//  TopTabViewController.h
//  TopTab
//
//  Created by Tolga Haliloğlu on 8.10.2018.
//  Copyright © 2018 Tolga Haliloğlu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MaterialTabs.h"
#import "MaterialTabs+ColorThemer.h"
#import "MaterialTabs+TypographyThemer.h"
#import "TopTabViewControllerExport.h"

NS_ASSUME_NONNULL_BEGIN

@interface TopTabViewController : UIViewController <TopTabViewControllerExport, UIPageViewControllerDataSource, UIPageViewControllerDelegate, MDCTabBarDelegate, MDCTabBarIndicatorTemplate>

@property (weak, nonatomic) MDCTabBar *topBar;
@property (weak, nonatomic) UIPageViewController *swipeView;

@property (nonatomic) NSArray *tabBarItems;
@property (nonatomic) UIColor *topBarBackgroundColor;
@property (nonatomic) UIColor *indicatorColor;
@property (nonatomic) NSInteger indicatorHeight;
@property (nonatomic) BOOL scrollEnabled;
@property (nonatomic) NSInteger currentIndex;
@property (nonatomic) UIViewController *previousViewController;
@property (nonatomic) UIViewController *pendingViewController;
@property (nonatomic, readonly) NSInteger barHeight;
- (void)setSelectedIndex:(NSInteger)index withAnimated:(BOOL)animated;
@property (nonatomic) UIColor *iconColor;
@property (nonatomic) UIColor *selectedIconColor;
@property (nonatomic) UIColor *titleColor;
@property (nonatomic) UIColor *selectedTitleColor;

@property (nonatomic) JSValue *onViewLoad;
@property (nonatomic) JSValue *onLoad;
@property (nonatomic) JSValue *onShow;
@property (nonatomic) JSValue *onHide;
@property (nonatomic) JSValue *onViewDidAppear;
@property (nonatomic) JSValue *onViewSafeAreaInsetsDidChange;
@property (nonatomic) JSValue *onViewLayoutSubviews;
@property (nonatomic) JSValue *viewWillTransition;
@property (nonatomic) JSValue *viewWillTransitionAnimate;
@property (nonatomic) JSValue *viewWillTransitionCompletion;
@property (nonatomic) NSArray *orientations;

@property (nonatomic) JSValue *viewControllerForIndex;
@property (nonatomic) JSValue *tabWillSelectAtIndex;

@end

NS_ASSUME_NONNULL_END

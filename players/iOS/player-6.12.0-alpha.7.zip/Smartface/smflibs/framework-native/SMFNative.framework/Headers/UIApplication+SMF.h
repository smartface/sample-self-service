//
//  UIApplication+SMF.h
//  SMFNative
//
//  Created by Dogan Ekici on 27.12.2018.
//  Copyright © 2018 Dogan Ekici. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <JavaScriptCore/JavaScriptCore.h>

@protocol UIApplicationExport <JSExport, NSObject>

@property(nonatomic,readonly) UIWindow *keyWindow;

+ (UIApplication *)sharedApplication;
- (void)setStatusBarHidden:(BOOL)hidden withAnimation:(UIStatusBarAnimation)animation;
@property(nonatomic,readonly) CGRect statusBarFrame;
- (BOOL)canOpenURL:(NSURL *)url NS_AVAILABLE_IOS(3_0);

- (void)registerUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings;
@property(nonatomic, readonly) UIUserNotificationSettings *currentUserNotificationSettings;

- (void)registerForRemoteNotifications;
- (void)unregisterForRemoteNotifications;
@property(nonatomic, readonly, getter=isRegisteredForRemoteNotifications) BOOL registeredForRemoteNotifications;

- (void)scheduleLocalNotification:(UILocalNotification *)notification;
- (void)presentLocalNotificationNow:(UILocalNotification *)notification;
- (void)cancelLocalNotification:(UILocalNotification *)notification;
- (void)cancelAllLocalNotifications;
@property(nonatomic, copy) NSArray<UILocalNotification *> *scheduledLocalNotifications;

@property(nonatomic) NSInteger applicationIconBadgeNumber;

@property(readonly, nonatomic) UIInterfaceOrientation statusBarOrientation __TVOS_PROHIBITED;

@property(nonatomic,readonly) NSTimeInterval statusBarOrientationAnimationDuration;

@property(nonatomic,readonly) UIUserInterfaceLayoutDirection userInterfaceLayoutDirection NS_AVAILABLE_IOS(5_0);
@property (nonatomic, assign) BOOL sf_statusBarHidden;
@property (nonatomic) UIStatusBarStyle sf_statusBarStyle;

@end

@interface UIApplication (SMF) <UIApplicationExport>

@property (nonatomic, assign) BOOL sf_statusBarHidden;
@property (nonatomic) UIStatusBarStyle sf_statusBarStyle;

@end


///////////////////////////////////////////////////////////////////////////
//UIUserNotificationSettings
@protocol UIUserNotificationSettingsExport <NSObject, JSExport>

+ (instancetype)settingsForTypes:(UIUserNotificationType)types categories:(NSSet<UIUserNotificationCategory *> *)categories;

@property(nonatomic, readonly) UIUserNotificationType types;
@property(nonatomic, copy, readonly) NSSet<UIUserNotificationCategory *> *categories;

@end

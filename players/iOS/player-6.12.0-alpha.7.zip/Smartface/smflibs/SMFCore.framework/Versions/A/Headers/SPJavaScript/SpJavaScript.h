//
//  SpJavaScript.h
//  SpratIOS
//
//  Created by Antti Panula on 30.10.2012 -- 5.
//  Copyright (c) 2012 Bivium. All rights reserved.
//

#ifndef SpratIOS_SpJavaScript_h
#define SpratIOS_SpJavaScript_h

#include "SpJSCommon.h"
#include "SpJSApplication.h"

#endif

#include "SpJsEngine/Core/SpJsEngine.h"
//
//  SpJSFunctionsDevice.h
//  SpratIOS
//
//  Created by Antti Panula on 12/7/12.
//  Copyright (c) 2012 Bivium. All rights reserved.
//

#ifndef __SpratIOS__SpJSFunctionsDevice__
#define __SpratIOS__SpJSFunctionsDevice__

SpJsFunction (cb_restart);

#endif /* defined(__SpratIOS__SpJSFunctionsDevice__) */

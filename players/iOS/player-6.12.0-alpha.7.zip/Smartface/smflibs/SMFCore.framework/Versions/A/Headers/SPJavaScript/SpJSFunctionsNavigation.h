#include "SpJsEngine/Core/SpJsEngine.h"
//
//  SpJSFunctionsNavigation.h
//  SpratIOS
//
//  Created by Antti Panula on 1.11.2012 -- 1.
//  Copyright (c) 2012 Bivium. All rights reserved.
//

#ifndef SpratIOS_SpJSFunctionsNavigation_h
#define SpratIOS_SpJSFunctionsNavigation_h

SpJsFunction (cb_navigation_callApplication);

SpJsFunction (cb_navigation_exit);

#endif
